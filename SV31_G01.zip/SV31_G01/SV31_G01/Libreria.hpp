#include <string>
#include <vector>
#include <fstream>
#include <list>
#include <sstream>
#include <iostream>
#include <functional>
#include <iterator>
#include <stack>
#include <queue>
#include <algorithm>
#include <windows.h>
#include <conio.h>
#include <time.h>
#include <stdlib.h>
#include <math.h>


using namespace std;